var dir_a97ba3293ba17ad64a94665a34f43bb5 =
[
    [ "Exceptions", "dir_24d33388b96a53029e0f57f146eae9bc.html", "dir_24d33388b96a53029e0f57f146eae9bc" ],
    [ "Model", "dir_07a811335cd35bbd8b81ac7cebd2e41a.html", "dir_07a811335cd35bbd8b81ac7cebd2e41a" ],
    [ "GenericMetadataManager.cs", "_generic_metadata_manager_8cs.html", [
      [ "GenericMetadataManager", "class_neosmartpen_1_1_net_1_1_metadata_1_1_generic_metadata_manager.html", "class_neosmartpen_1_1_net_1_1_metadata_1_1_generic_metadata_manager" ]
    ] ],
    [ "IMetadataManager.cs", "_i_metadata_manager_8cs.html", [
      [ "IMetadataManager", "interface_neosmartpen_1_1_net_1_1_metadata_1_1_i_metadata_manager.html", "interface_neosmartpen_1_1_net_1_1_metadata_1_1_i_metadata_manager" ]
    ] ],
    [ "IMetadataParser.cs", "_i_metadata_parser_8cs.html", [
      [ "IMetadataParser", "interface_neosmartpen_1_1_net_1_1_metadata_1_1_i_metadata_parser.html", "interface_neosmartpen_1_1_net_1_1_metadata_1_1_i_metadata_parser" ]
    ] ],
    [ "NprojParser.cs", "_nproj_parser_8cs.html", [
      [ "NProjParser", "class_neosmartpen_1_1_net_1_1_metadata_1_1_n_proj_parser.html", "class_neosmartpen_1_1_net_1_1_metadata_1_1_n_proj_parser" ]
    ] ]
];
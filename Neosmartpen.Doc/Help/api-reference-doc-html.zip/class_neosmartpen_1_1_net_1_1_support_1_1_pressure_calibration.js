var class_neosmartpen_1_1_net_1_1_support_1_1_pressure_calibration =
[
    [ "PressureCalibration", "class_neosmartpen_1_1_net_1_1_support_1_1_pressure_calibration.html#ab60e688fd8230fd79f146af408ec7f94", null ],
    [ "Clear", "class_neosmartpen_1_1_net_1_1_support_1_1_pressure_calibration.html#aaafb7c5027728e2924723a478bfcfa31", null ],
    [ "GetPressureCalibrateFactor", "class_neosmartpen_1_1_net_1_1_support_1_1_pressure_calibration.html#a5f8e3e8fe3d7aaa6ccade4b31a3f49a4", null ],
    [ "MakeFactor", "class_neosmartpen_1_1_net_1_1_support_1_1_pressure_calibration.html#afe6f477272365045d59cc4d7d36ddafd", null ],
    [ "MAX_FACTOR", "class_neosmartpen_1_1_net_1_1_support_1_1_pressure_calibration.html#ad11e6ab2db9ce5e89581d0e3fa33ef31", null ],
    [ "Factor", "class_neosmartpen_1_1_net_1_1_support_1_1_pressure_calibration.html#a05d6ab8b8a625c331d204c1a5c803300", null ]
];
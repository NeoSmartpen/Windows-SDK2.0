var class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_image_processing_info =
[
    [ "DotCount", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_image_processing_info.html#a3219a0a5a5463bbd637f8fd6d3fc0bab", null ],
    [ "Processed", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_image_processing_info.html#aa72c66e71b4d02f8c85057c3e6007c28", null ],
    [ "Success", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_image_processing_info.html#ae31629eb5fa52804fa6e735c11d8a664", null ],
    [ "Total", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_image_processing_info.html#aaaca0bd8d1d7036d443a3fafa0c1d8bb", null ],
    [ "Transferred", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_image_processing_info.html#ab34708613368771c8d6aed66972ba14b", null ]
];
var interface_neosmartpen_1_1_net_1_1_metadata_1_1_i_metadata_parser =
[
    [ "Parse", "interface_neosmartpen_1_1_net_1_1_metadata_1_1_i_metadata_parser.html#abb5e6da685deacdbf6e3dfe807ca0c2e", null ]
];
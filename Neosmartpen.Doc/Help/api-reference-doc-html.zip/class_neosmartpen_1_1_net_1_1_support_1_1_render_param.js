var class_neosmartpen_1_1_net_1_1_support_1_1_render_param =
[
    [ "RenderParam", "class_neosmartpen_1_1_net_1_1_support_1_1_render_param.html#afe87a107837bba4976484fa5a08e3b76", null ],
    [ "RenderParam", "class_neosmartpen_1_1_net_1_1_support_1_1_render_param.html#a4a2850d11c676995370b0970d83de5f7", null ],
    [ "setThickness", "class_neosmartpen_1_1_net_1_1_support_1_1_render_param.html#a00fb643ade694c34722756298e10e0cd", null ],
    [ "base_thickness", "class_neosmartpen_1_1_net_1_1_support_1_1_render_param.html#a195302d5f4c5c16f69182b6008a2223a", null ],
    [ "dpi", "class_neosmartpen_1_1_net_1_1_support_1_1_render_param.html#adf2daf4e40cd4414ea1213fead30c550", null ],
    [ "scale", "class_neosmartpen_1_1_net_1_1_support_1_1_render_param.html#a4858f8b407d5547cc4eaad57b21f9088", null ]
];
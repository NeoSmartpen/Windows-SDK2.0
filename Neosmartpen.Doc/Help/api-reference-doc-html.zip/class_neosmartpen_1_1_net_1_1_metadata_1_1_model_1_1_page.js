var class_neosmartpen_1_1_net_1_1_metadata_1_1_model_1_1_page =
[
    [ "Book", "class_neosmartpen_1_1_net_1_1_metadata_1_1_model_1_1_page.html#a181f56f49401c103ac2ded5e07085ca9", null ],
    [ "MarginB", "class_neosmartpen_1_1_net_1_1_metadata_1_1_model_1_1_page.html#a07fec606261b6dae8030cbf9f8538c74", null ],
    [ "MarginL", "class_neosmartpen_1_1_net_1_1_metadata_1_1_model_1_1_page.html#ab7cc1a9e32a326aaed3b1b8f5f63dbe3", null ],
    [ "MarginR", "class_neosmartpen_1_1_net_1_1_metadata_1_1_model_1_1_page.html#abf344f61ad9cd4efb940a372ff5dd546", null ],
    [ "MarginT", "class_neosmartpen_1_1_net_1_1_metadata_1_1_model_1_1_page.html#ad817313e7a78abfc63453c90d39acb36", null ],
    [ "Number", "class_neosmartpen_1_1_net_1_1_metadata_1_1_model_1_1_page.html#af9bef704620374e55d0531262b211067", null ],
    [ "Owner", "class_neosmartpen_1_1_net_1_1_metadata_1_1_model_1_1_page.html#a948e04bb7fb76815f6927c815a8de141", null ],
    [ "Section", "class_neosmartpen_1_1_net_1_1_metadata_1_1_model_1_1_page.html#a9983583038d4ef665a66d48e1f27e1a2", null ],
    [ "X1", "class_neosmartpen_1_1_net_1_1_metadata_1_1_model_1_1_page.html#aa2d3f3041e7229864113f248208aef3f", null ],
    [ "X2", "class_neosmartpen_1_1_net_1_1_metadata_1_1_model_1_1_page.html#a28454a96e8126ac7e7a8fed46150e46d", null ],
    [ "Y1", "class_neosmartpen_1_1_net_1_1_metadata_1_1_model_1_1_page.html#a9321f254751b70e92fdb2e6187b41c42", null ],
    [ "Y2", "class_neosmartpen_1_1_net_1_1_metadata_1_1_model_1_1_page.html#affd8b06ad27d729ad94603ab64c1611f", null ]
];
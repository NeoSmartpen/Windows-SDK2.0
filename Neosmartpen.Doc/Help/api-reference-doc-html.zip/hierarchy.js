var hierarchy =
[
    [ "ApplicationSettingsBase", null, [
      [ "PenDemo.Properties.Settings", "class_pen_demo_1_1_properties_1_1_settings.html", null ]
    ] ],
    [ "Neosmartpen.Net.Bluetooth.BluetoothAdapter", "class_neosmartpen_1_1_net_1_1_bluetooth_1_1_bluetooth_adapter.html", null ],
    [ "Neosmartpen.Net.Metadata.Model.Book", "class_neosmartpen_1_1_net_1_1_metadata_1_1_model_1_1_book.html", null ],
    [ "Neosmartpen.Net.Dot.Builder", "class_neosmartpen_1_1_net_1_1_dot_1_1_builder.html", null ],
    [ "Neosmartpen.Net.Packet.Builder", "class_neosmartpen_1_1_net_1_1_packet_1_1_builder.html", null ],
    [ "Neosmartpen.Net.Support.ByteConverter", "class_neosmartpen_1_1_net_1_1_support_1_1_byte_converter.html", null ],
    [ "Neosmartpen.Net.Support.ByteUtil", "class_neosmartpen_1_1_net_1_1_support_1_1_byte_util.html", null ],
    [ "Neosmartpen.Net.Chunk", "class_neosmartpen_1_1_net_1_1_chunk.html", null ],
    [ "Neosmartpen.Net.Protocol.v2.Const", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_const.html", null ],
    [ "Neosmartpen.Net.Protocol.v2.PenProfileDeleteValueCallbackArgs.DeleteValueResult", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_profile_delete_value_callback_args_1_1_delete_value_result.html", null ],
    [ "Neosmartpen.Net.Dot", "class_neosmartpen_1_1_net_1_1_dot.html", null ],
    [ "EventArgs", null, [
      [ "Neosmartpen.Net.PacketEventArgs", "class_neosmartpen_1_1_net_1_1_packet_event_args.html", null ]
    ] ],
    [ "Exception", null, [
      [ "Neosmartpen.Net.Metadata.Exceptions.ParseException", "class_neosmartpen_1_1_net_1_1_metadata_1_1_exceptions_1_1_parse_exception.html", null ]
    ] ],
    [ "Neosmartpen.Net.Filter.FilterForPaper", "class_neosmartpen_1_1_net_1_1_filter_1_1_filter_for_paper.html", null ],
    [ "Neosmartpen.Net.Support.FloatConverter", "class_neosmartpen_1_1_net_1_1_support_1_1_float_converter.html", null ],
    [ "Form", null, [
      [ "PenDemo.MainForm", "class_pen_demo_1_1_main_form.html", null ],
      [ "PenDemo.PasswordInputForm", "class_pen_demo_1_1_password_input_form.html", null ],
      [ "PenDemo.ProgressForm", "class_pen_demo_1_1_progress_form.html", null ]
    ] ],
    [ "IDisposable", null, [
      [ "Neosmartpen.Net.PenCommAgent", "class_neosmartpen_1_1_net_1_1_pen_comm_agent.html", null ]
    ] ],
    [ "Neosmartpen.Net.ImageProcessErrorInfo", "class_neosmartpen_1_1_net_1_1_image_process_error_info.html", null ],
    [ "Neosmartpen.Net.Protocol.v2.ImageProcessingInfo", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_image_processing_info.html", null ],
    [ "Neosmartpen.Net.Metadata.IMetadataManager", "interface_neosmartpen_1_1_net_1_1_metadata_1_1_i_metadata_manager.html", [
      [ "Neosmartpen.Net.Metadata.GenericMetadataManager", "class_neosmartpen_1_1_net_1_1_metadata_1_1_generic_metadata_manager.html", null ]
    ] ],
    [ "Neosmartpen.Net.Metadata.IMetadataParser", "interface_neosmartpen_1_1_net_1_1_metadata_1_1_i_metadata_parser.html", [
      [ "Neosmartpen.Net.Metadata.NProjParser", "class_neosmartpen_1_1_net_1_1_metadata_1_1_n_proj_parser.html", null ]
    ] ],
    [ "Neosmartpen.Net.IPacket", "interface_neosmartpen_1_1_net_1_1_i_packet.html", [
      [ "Neosmartpen.Net.Packet", "class_neosmartpen_1_1_net_1_1_packet.html", null ]
    ] ],
    [ "Neosmartpen.Net.IPenComm", "interface_neosmartpen_1_1_net_1_1_i_pen_comm.html", [
      [ "Neosmartpen.Net.PenComm", "class_neosmartpen_1_1_net_1_1_pen_comm.html", [
        [ "Neosmartpen.Net.Protocol.v1.PenCommV1", "class_neosmartpen_1_1_net_1_1_protocol_1_1v1_1_1_pen_comm_v1.html", null ],
        [ "Neosmartpen.Net.Protocol.v2.PenCommV2", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_comm_v2.html", null ]
      ] ]
    ] ],
    [ "Neosmartpen.Net.IProtocolParser", "interface_neosmartpen_1_1_net_1_1_i_protocol_parser.html", [
      [ "Neosmartpen.Net.Protocol.v1.ProtocolParserV1", "class_neosmartpen_1_1_net_1_1_protocol_1_1v1_1_1_protocol_parser_v1.html", null ],
      [ "Neosmartpen.Net.Protocol.v2.ProtocolParserV2", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_protocol_parser_v2.html", null ]
    ] ],
    [ "List", null, [
      [ "Neosmartpen.Net.Stroke", "class_neosmartpen_1_1_net_1_1_stroke.html", null ]
    ] ],
    [ "PenDemo.Log", "class_pen_demo_1_1_log.html", null ],
    [ "Neosmartpen.Net.Support.NConvert", "class_neosmartpen_1_1_net_1_1_support_1_1_n_convert.html", null ],
    [ "Neosmartpen.Net.Protocol.v1.OfflineData", "class_neosmartpen_1_1_net_1_1_protocol_1_1v1_1_1_offline_data.html", [
      [ "Neosmartpen.Net.Protocol.v1.OfflineDataParser", "class_neosmartpen_1_1_net_1_1_protocol_1_1v1_1_1_offline_data_parser.html", null ],
      [ "Neosmartpen.Net.Protocol.v1.OfflineDataSerializer", "class_neosmartpen_1_1_net_1_1_protocol_1_1v1_1_1_offline_data_serializer.html", null ],
      [ "Neosmartpen.Net.Protocol.v1.OfflineWorker", "class_neosmartpen_1_1_net_1_1_protocol_1_1v1_1_1_offline_worker.html", null ]
    ] ],
    [ "Neosmartpen.Net.OfflineDataFile", "class_neosmartpen_1_1_net_1_1_offline_data_file.html", null ],
    [ "Neosmartpen.Net.OfflineDataInfo", "class_neosmartpen_1_1_net_1_1_offline_data_info.html", null ],
    [ "Neosmartpen.Net.Protocol.v1.OfflineWorkResponseHandler", "interface_neosmartpen_1_1_net_1_1_protocol_1_1v1_1_1_offline_work_response_handler.html", [
      [ "Neosmartpen.Net.Protocol.v1.PenCommV1", "class_neosmartpen_1_1_net_1_1_protocol_1_1v1_1_1_pen_comm_v1.html", null ]
    ] ],
    [ "Neosmartpen.Net.Metadata.Model.Page", "class_neosmartpen_1_1_net_1_1_metadata_1_1_model_1_1_page.html", null ],
    [ "PenCommV1Callbacks", null, [
      [ "PenDemo.MainForm", "class_pen_demo_1_1_main_form.html", null ]
    ] ],
    [ "Neosmartpen.Net.Protocol.v1.PenCommV1Callbacks", "interface_neosmartpen_1_1_net_1_1_protocol_1_1v1_1_1_pen_comm_v1_callbacks.html", [
      [ "Neosmartpen.UnitTest.PenCommV1CallbacksImpl", "class_neosmartpen_1_1_unit_test_1_1_pen_comm_v1_callbacks_impl.html", null ]
    ] ],
    [ "Neosmartpen.Net.Protocol.v2.PenCommV2Callbacks", "interface_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_comm_v2_callbacks.html", [
      [ "Neosmartpen.UnitTest.BluetoothAdapterUnitTest", "class_neosmartpen_1_1_unit_test_1_1_bluetooth_adapter_unit_test.html", null ],
      [ "Neosmartpen.UnitTest.PenCommV2CallbacksImpl", "class_neosmartpen_1_1_unit_test_1_1_pen_comm_v2_callbacks_impl.html", null ]
    ] ],
    [ "PenCommV2Callbacks", null, [
      [ "PenDemo.MainForm", "class_pen_demo_1_1_main_form.html", null ]
    ] ],
    [ "Neosmartpen.Net.Bluetooth.PenDevice", "class_neosmartpen_1_1_net_1_1_bluetooth_1_1_pen_device.html", null ],
    [ "Neosmartpen.Net.Protocol.v2.PenProfile", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_profile.html", null ],
    [ "Neosmartpen.Net.Protocol.v2.PenProfileReceivedCallbackArgs", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_profile_received_callback_args.html", [
      [ "Neosmartpen.Net.Protocol.v2.PenProfileCreateCallbackArgs", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_profile_create_callback_args.html", null ],
      [ "Neosmartpen.Net.Protocol.v2.PenProfileDeleteCallbackArgs", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_profile_delete_callback_args.html", null ],
      [ "Neosmartpen.Net.Protocol.v2.PenProfileDeleteValueCallbackArgs", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_profile_delete_value_callback_args.html", null ],
      [ "Neosmartpen.Net.Protocol.v2.PenProfileInfoCallbackArgs", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_profile_info_callback_args.html", null ],
      [ "Neosmartpen.Net.Protocol.v2.PenProfileReadValueCallbackArgs", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_profile_read_value_callback_args.html", null ],
      [ "Neosmartpen.Net.Protocol.v2.PenProfileWriteValueCallbackArgs", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_profile_write_value_callback_args.html", null ]
    ] ],
    [ "Neosmartpen.Net.Support.PressureCalibration", "class_neosmartpen_1_1_net_1_1_support_1_1_pressure_calibration.html", null ],
    [ "Neosmartpen.Net.Support.PressureFilter", "class_neosmartpen_1_1_net_1_1_support_1_1_pressure_filter.html", null ],
    [ "Neosmartpen.UnitTest.ProtocolVersion1UnitTest", "class_neosmartpen_1_1_unit_test_1_1_protocol_version1_unit_test.html", null ],
    [ "Neosmartpen.UnitTest.ProtocolVersion2UnitTest", "class_neosmartpen_1_1_unit_test_1_1_protocol_version2_unit_test.html", null ],
    [ "Neosmartpen.Net.Protocol.v2.PenProfileReadValueCallbackArgs.ReadValueResult", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_profile_read_value_callback_args_1_1_read_value_result.html", null ],
    [ "Neosmartpen.Net.Support.Renderer", "class_neosmartpen_1_1_net_1_1_support_1_1_renderer.html", null ],
    [ "Neosmartpen.Net.Support.RenderParam", "class_neosmartpen_1_1_net_1_1_support_1_1_render_param.html", null ],
    [ "Neosmartpen.Net.Support.RenderStroke", "class_neosmartpen_1_1_net_1_1_support_1_1_render_stroke.html", null ],
    [ "PenDemo.Properties.Resources", "class_pen_demo_1_1_properties_1_1_resources.html", null ],
    [ "Neosmartpen.Net.Metadata.Model.Symbol", "class_neosmartpen_1_1_net_1_1_metadata_1_1_model_1_1_symbol.html", null ],
    [ "Neosmartpen.Net.Support.Time", "class_neosmartpen_1_1_net_1_1_support_1_1_time.html", null ],
    [ "Neosmartpen.Net.Protocol.v2.PenProfileWriteValueCallbackArgs.WriteValueResult", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_profile_write_value_callback_args_1_1_write_value_result.html", null ]
];
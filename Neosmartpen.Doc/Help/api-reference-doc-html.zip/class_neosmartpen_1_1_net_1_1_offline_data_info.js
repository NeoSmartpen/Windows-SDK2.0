var class_neosmartpen_1_1_net_1_1_offline_data_info =
[
    [ "OfflineDataInfo", "class_neosmartpen_1_1_net_1_1_offline_data_info.html#a226072ff9e9f69de9cf100509eef1a89", null ],
    [ "ToString", "class_neosmartpen_1_1_net_1_1_offline_data_info.html#aa9ece756c58411d72ce2d1f031788412", null ],
    [ "Note", "class_neosmartpen_1_1_net_1_1_offline_data_info.html#a06cf1d23dac1f501930b56363d3685ff", null ],
    [ "Owner", "class_neosmartpen_1_1_net_1_1_offline_data_info.html#ae77e71b2a2f685f61c9a1bad41e07ce2", null ],
    [ "Pages", "class_neosmartpen_1_1_net_1_1_offline_data_info.html#aa0373cb8e680dcf5ac5e2f5c629a3259", null ],
    [ "Section", "class_neosmartpen_1_1_net_1_1_offline_data_info.html#aa9614d15b2eecb892b7b3fb5a204e2c6", null ]
];
var namespace_neosmartpen_1_1_net_1_1_filter =
[
    [ "FilterForPaper", "class_neosmartpen_1_1_net_1_1_filter_1_1_filter_for_paper.html", "class_neosmartpen_1_1_net_1_1_filter_1_1_filter_for_paper" ]
];
var class_neosmartpen_1_1_net_1_1_support_1_1_render_stroke =
[
    [ "clear", "class_neosmartpen_1_1_net_1_1_support_1_1_render_stroke.html#a037933f9caff3e5a64b372ca51aa1f07", null ],
    [ "createPointArray", "class_neosmartpen_1_1_net_1_1_support_1_1_render_stroke.html#a93bb88c51a72a7ef56687dc39d7b4e0d", null ],
    [ "dotCount", "class_neosmartpen_1_1_net_1_1_support_1_1_render_stroke.html#ad97da236a4ec9fb8bf86d7c2fd959914", null ],
    [ "fPressureRate", "class_neosmartpen_1_1_net_1_1_support_1_1_render_stroke.html#a448ff3974528fb1911126accfe9fc2c9", null ],
    [ "fX", "class_neosmartpen_1_1_net_1_1_support_1_1_render_stroke.html#a2d82c86f2b7b3edea70971b4fdddbb88", null ],
    [ "fY", "class_neosmartpen_1_1_net_1_1_support_1_1_render_stroke.html#ace098fa1ceaa92a58f32b0a93f1928fe", null ],
    [ "timestampDelta", "class_neosmartpen_1_1_net_1_1_support_1_1_render_stroke.html#a30ae9875cfccf85dfca5e724a504b939", null ]
];
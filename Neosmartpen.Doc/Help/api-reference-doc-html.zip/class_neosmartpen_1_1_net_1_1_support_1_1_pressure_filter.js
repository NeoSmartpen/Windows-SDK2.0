var class_neosmartpen_1_1_net_1_1_support_1_1_pressure_filter =
[
    [ "PressureFilter", "class_neosmartpen_1_1_net_1_1_support_1_1_pressure_filter.html#a56830b419a1183585f29b745b948bf1c", null ],
    [ "Filter", "class_neosmartpen_1_1_net_1_1_support_1_1_pressure_filter.html#a9da3738966e08f01bab5db6db334962c", null ],
    [ "Reset", "class_neosmartpen_1_1_net_1_1_support_1_1_pressure_filter.html#a2cdd2e493f6d3795c9f11ff96d0af86c", null ],
    [ "ToRate", "class_neosmartpen_1_1_net_1_1_support_1_1_pressure_filter.html#a6eef2997365474ce671807cd162fa4ce", null ],
    [ "RANGE", "class_neosmartpen_1_1_net_1_1_support_1_1_pressure_filter.html#a0262b4060b848d5bdef382f1c5105c22", null ],
    [ "RANGE_MIN", "class_neosmartpen_1_1_net_1_1_support_1_1_pressure_filter.html#aa1321a7f8821eedb1fcc9561f35574bb", null ]
];
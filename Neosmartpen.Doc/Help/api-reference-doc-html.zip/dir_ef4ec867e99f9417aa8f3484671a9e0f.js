var dir_ef4ec867e99f9417aa8f3484671a9e0f =
[
    [ "AssemblyInfo.cs", "_neosmartpen_8_net_8_protocol_8v2_2_properties_2_assembly_info_8cs.html", null ]
];
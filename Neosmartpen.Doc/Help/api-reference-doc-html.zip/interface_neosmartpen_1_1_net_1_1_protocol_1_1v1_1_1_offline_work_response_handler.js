var interface_neosmartpen_1_1_net_1_1_protocol_1_1v1_1_1_offline_work_response_handler =
[
    [ "onReceiveOfflineStrokes", "interface_neosmartpen_1_1_net_1_1_protocol_1_1v1_1_1_offline_work_response_handler.html#aa41ff1842a9944f4ed82811d0eacff25", null ],
    [ "onRequestDownloadOfflineData", "interface_neosmartpen_1_1_net_1_1_protocol_1_1v1_1_1_offline_work_response_handler.html#aed5a812298738163d50edec0acfced3f", null ],
    [ "onRequestRemoveOfflineData", "interface_neosmartpen_1_1_net_1_1_protocol_1_1v1_1_1_offline_work_response_handler.html#ac28a3e858d23c07715accef0a61f69da", null ]
];
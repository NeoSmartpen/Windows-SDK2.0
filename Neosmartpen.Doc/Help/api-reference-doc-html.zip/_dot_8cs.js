var _dot_8cs =
[
    [ "Dot", "class_neosmartpen_1_1_net_1_1_dot.html", "class_neosmartpen_1_1_net_1_1_dot" ],
    [ "Builder", "class_neosmartpen_1_1_net_1_1_dot_1_1_builder.html", "class_neosmartpen_1_1_net_1_1_dot_1_1_builder" ],
    [ "DotTypes", "_dot_8cs.html#a436075c76efafacbe7be890273e47cd9", [
      [ "PEN_DOWN", "_dot_8cs.html#a436075c76efafacbe7be890273e47cd9a115ca143fc40c712c28e276f874ff75d", null ],
      [ "PEN_MOVE", "_dot_8cs.html#a436075c76efafacbe7be890273e47cd9a7c4836ff95a4235cb0005f15796eb643", null ],
      [ "PEN_UP", "_dot_8cs.html#a436075c76efafacbe7be890273e47cd9aa57ba62997ee8a6b8f91ff57ecb8913e", null ],
      [ "PEN_HOVER", "_dot_8cs.html#a436075c76efafacbe7be890273e47cd9a960164f2b178cac4d0300f2a512ad3fb", null ],
      [ "PEN_ERROR", "_dot_8cs.html#a436075c76efafacbe7be890273e47cd9ae22555d9cf9046bbe5ca406926caabde", null ]
    ] ]
];
var dir_65facb54dee41af5d005747fb913c594 =
[
    [ "AssemblyInfo.cs", "_neosmartpen_8_demo_2_properties_2_assembly_info_8cs.html", null ],
    [ "Resources.Designer.cs", "_neosmartpen_8_demo_2_properties_2_resources_8_designer_8cs.html", [
      [ "Resources", "class_pen_demo_1_1_properties_1_1_resources.html", null ]
    ] ],
    [ "Settings.Designer.cs", "_neosmartpen_8_demo_2_properties_2_settings_8_designer_8cs.html", [
      [ "Settings", "class_pen_demo_1_1_properties_1_1_settings.html", "class_pen_demo_1_1_properties_1_1_settings" ]
    ] ]
];
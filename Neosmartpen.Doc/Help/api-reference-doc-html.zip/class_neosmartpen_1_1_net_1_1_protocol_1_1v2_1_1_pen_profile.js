var class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_profile =
[
    [ "PROFILE_STATUS_BUFFER_SIZE_ERR", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_profile.html#a5f3db42fb646fa1a0cdbba22fa986119", null ],
    [ "PROFILE_STATUS_EXIST_PROFILE_ALREADY", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_profile.html#a752a0bc9e8cb235c9246b25fc0ece60b", null ],
    [ "PROFILE_STATUS_FAILURE", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_profile.html#a7bf118126dd17c36a8b0da34704ec274", null ],
    [ "PROFILE_STATUS_NO_EXIST_KEY", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_profile.html#aeb831eedbe2b8973555eee9794418b15", null ],
    [ "PROFILE_STATUS_NO_EXIST_PROFILE", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_profile.html#ac140e46970980baf906b762dd7bb517e", null ],
    [ "PROFILE_STATUS_NO_PERMISSION", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_profile.html#a8bdf473d095dc5bbf6130d984e040241", null ],
    [ "PROFILE_STATUS_SUCCESS", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_profile.html#ab2aa9f605484032acc20407f293ff539", null ]
];
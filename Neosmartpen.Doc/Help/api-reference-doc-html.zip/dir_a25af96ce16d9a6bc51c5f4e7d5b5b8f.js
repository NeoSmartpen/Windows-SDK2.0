var dir_a25af96ce16d9a6bc51c5f4e7d5b5b8f =
[
    [ "AssemblyInfo.cs", "_neosmartpen_8_net_8_protocol_8v1_2_properties_2_assembly_info_8cs.html", null ]
];
var class_neosmartpen_1_1_net_1_1_packet_1_1_builder =
[
    [ "Builder", "class_neosmartpen_1_1_net_1_1_packet_1_1_builder.html#ac7a3a107756c8612a3cd3322f8823132", null ],
    [ "Build", "class_neosmartpen_1_1_net_1_1_packet_1_1_builder.html#aea346d97254b1b9b852a5895017bfee8", null ],
    [ "cmd", "class_neosmartpen_1_1_net_1_1_packet_1_1_builder.html#a8561cbd72a44006d6c3b20d630ee7769", null ],
    [ "data", "class_neosmartpen_1_1_net_1_1_packet_1_1_builder.html#aae188859dc713743dc7c2f7952bb68e7", null ],
    [ "result", "class_neosmartpen_1_1_net_1_1_packet_1_1_builder.html#a1ad00c3f3fff3a1dfc7e67c7e8ab12c1", null ]
];
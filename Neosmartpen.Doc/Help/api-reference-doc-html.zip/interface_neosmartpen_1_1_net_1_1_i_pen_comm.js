var interface_neosmartpen_1_1_net_1_1_i_pen_comm =
[
    [ "Bind", "interface_neosmartpen_1_1_net_1_1_i_pen_comm.html#af3434e61ff82295c7b57dbae43ad077e", null ],
    [ "Clean", "interface_neosmartpen_1_1_net_1_1_i_pen_comm.html#a0ac0a1f80b853f495d826f2685947abc", null ],
    [ "DeviceClass", "interface_neosmartpen_1_1_net_1_1_i_pen_comm.html#af2d8dd672cc9460f9151333cbe425510", null ],
    [ "Name", "interface_neosmartpen_1_1_net_1_1_i_pen_comm.html#a41dcce85b269b3ad3a5c30b8c7a595d0", null ],
    [ "Parser", "interface_neosmartpen_1_1_net_1_1_i_pen_comm.html#acf275cae16349dd39da024972ffd4e81", null ],
    [ "Version", "interface_neosmartpen_1_1_net_1_1_i_pen_comm.html#aa4954b349dc541fa3fdb4950431b7326", null ]
];
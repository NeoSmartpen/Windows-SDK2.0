var dir_352658346ea3e8ec08a5e98107cc4c65 =
[
    [ "AssemblyInfo.cs", "_neosmartpen_8_demo_2_properties_2_assembly_info_8cs.html", null ],
    [ "Resources.Designer.cs", "_resources_8_designer_8cs.html", [
      [ "Resources", "class_pen_demo_1_1_properties_1_1_resources.html", null ]
    ] ],
    [ "Settings.Designer.cs", "_settings_8_designer_8cs.html", [
      [ "Settings", "class_pen_demo_1_1_properties_1_1_settings.html", "class_pen_demo_1_1_properties_1_1_settings" ]
    ] ]
];
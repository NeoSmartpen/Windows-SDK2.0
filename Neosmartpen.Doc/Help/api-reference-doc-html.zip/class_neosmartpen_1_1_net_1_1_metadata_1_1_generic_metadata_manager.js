var class_neosmartpen_1_1_net_1_1_metadata_1_1_generic_metadata_manager =
[
    [ "GenericMetadataManager", "class_neosmartpen_1_1_net_1_1_metadata_1_1_generic_metadata_manager.html#a4502b7bbf586251e73b6e1c2d0165868", null ],
    [ "FindApplicableSymbols", "class_neosmartpen_1_1_net_1_1_metadata_1_1_generic_metadata_manager.html#a2c457cd92360d05106b9fb12297a49f6", null ],
    [ "GetBook", "class_neosmartpen_1_1_net_1_1_metadata_1_1_generic_metadata_manager.html#ab03dfc72a9b3f5cc655ff033431ce7d5", null ],
    [ "GetPage", "class_neosmartpen_1_1_net_1_1_metadata_1_1_generic_metadata_manager.html#ae6ef07f3469a4ee944676b4063c1ad1d", null ],
    [ "GetStrokesInSymbol", "class_neosmartpen_1_1_net_1_1_metadata_1_1_generic_metadata_manager.html#a5952a1eaa147b5ef67f780ccc94f5740", null ],
    [ "GetSymbols", "class_neosmartpen_1_1_net_1_1_metadata_1_1_generic_metadata_manager.html#a4e94b275965a34c1a436e4cb84dc722c", null ],
    [ "Load", "class_neosmartpen_1_1_net_1_1_metadata_1_1_generic_metadata_manager.html#af753da4456dec5c4adeabc8fa9972982", null ],
    [ "Parser", "class_neosmartpen_1_1_net_1_1_metadata_1_1_generic_metadata_manager.html#a5ea779d8938b179ca6e6819fd9ffa0e0", null ]
];
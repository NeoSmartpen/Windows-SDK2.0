var dir_4ff9963d7d0daae29612e66b0d4bec29 =
[
    [ "CallbackArgs", "dir_041aef0003fc49ee8d7807bfefa8db78.html", "dir_041aef0003fc49ee8d7807bfefa8db78" ],
    [ "ImageProcessErrorInfo.cs", "_image_process_error_info_8cs.html", [
      [ "ImageProcessErrorInfo", "class_neosmartpen_1_1_net_1_1_image_process_error_info.html", "class_neosmartpen_1_1_net_1_1_image_process_error_info" ]
    ] ],
    [ "ImageProcessingInfo.cs", "_image_processing_info_8cs.html", [
      [ "ImageProcessingInfo", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_image_processing_info.html", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_image_processing_info" ]
    ] ],
    [ "PenCommV2.cs", "_pen_comm_v2_8cs.html", [
      [ "PenCommV2", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_comm_v2.html", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_comm_v2" ]
    ] ],
    [ "PenCommV2Callbacks.cs", "_pen_comm_v2_callbacks_8cs.html", [
      [ "PenCommV2Callbacks", "interface_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_comm_v2_callbacks.html", "interface_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_comm_v2_callbacks" ]
    ] ],
    [ "PenProfile.cs", "_pen_profile_8cs.html", [
      [ "PenProfile", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_profile.html", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_profile" ]
    ] ],
    [ "Protocol.cs", "_protocol_8cs.html", "_protocol_8cs" ],
    [ "ProtocolParserV2.cs", "_protocol_parser_v2_8cs.html", [
      [ "ProtocolParserV2", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_protocol_parser_v2.html", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_protocol_parser_v2" ]
    ] ]
];
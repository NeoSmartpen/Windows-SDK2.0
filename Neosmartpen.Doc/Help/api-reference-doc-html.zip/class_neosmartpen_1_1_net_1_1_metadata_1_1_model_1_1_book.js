var class_neosmartpen_1_1_net_1_1_metadata_1_1_model_1_1_book =
[
    [ "Code", "class_neosmartpen_1_1_net_1_1_metadata_1_1_model_1_1_book.html#a9c197593c6715b24892d634d371b0d38", null ],
    [ "Dpi", "class_neosmartpen_1_1_net_1_1_metadata_1_1_model_1_1_book.html#a40fe69ec28667226bc3a4928082cd6b7", null ],
    [ "ExtraInfo", "class_neosmartpen_1_1_net_1_1_metadata_1_1_model_1_1_book.html#a60888e6b138774a9c6fe297b2ef20cb5", null ],
    [ "isLine", "class_neosmartpen_1_1_net_1_1_metadata_1_1_model_1_1_book.html#a4371aab0fba476e4bb0f7f08182b8d48", null ],
    [ "Kind", "class_neosmartpen_1_1_net_1_1_metadata_1_1_model_1_1_book.html#aa181bfcdefa2309f0493388c1283eb66", null ],
    [ "LineSegmentLength", "class_neosmartpen_1_1_net_1_1_metadata_1_1_model_1_1_book.html#a04f083fad3527af25454dbe1802e137f", null ],
    [ "OffsetLeft", "class_neosmartpen_1_1_net_1_1_metadata_1_1_model_1_1_book.html#a256c202405c67cec3dfade5ee5eb3118", null ],
    [ "OffsetTop", "class_neosmartpen_1_1_net_1_1_metadata_1_1_model_1_1_book.html#a48c6c6c4fce0659ca5c13b394b4c88e5", null ],
    [ "Owner", "class_neosmartpen_1_1_net_1_1_metadata_1_1_model_1_1_book.html#ad9a336c3424d8277f4ab94e909bca7a1", null ],
    [ "Pages", "class_neosmartpen_1_1_net_1_1_metadata_1_1_model_1_1_book.html#abc5ae70a096f59aab12affd1649bd9cc", null ],
    [ "Revision", "class_neosmartpen_1_1_net_1_1_metadata_1_1_model_1_1_book.html#ae351dd69db862d079a6191ccaa928445", null ],
    [ "Section", "class_neosmartpen_1_1_net_1_1_metadata_1_1_model_1_1_book.html#aa7742576a83d1992ecdc166ebb941bd2", null ],
    [ "StartPage", "class_neosmartpen_1_1_net_1_1_metadata_1_1_model_1_1_book.html#a7000a575f9e1d35212e92700b2743130", null ],
    [ "StartPageSide", "class_neosmartpen_1_1_net_1_1_metadata_1_1_model_1_1_book.html#a9b73d330d5bb2956926689533c503df7", null ],
    [ "Symbols", "class_neosmartpen_1_1_net_1_1_metadata_1_1_model_1_1_book.html#aa6d915f5c8b472e26129307c10c4604b", null ],
    [ "Title", "class_neosmartpen_1_1_net_1_1_metadata_1_1_model_1_1_book.html#a5a919b2536ad40a2f787e5bf5765255c", null ],
    [ "TotalPageCount", "class_neosmartpen_1_1_net_1_1_metadata_1_1_model_1_1_book.html#a2d348ac4c07b5a7ce223df714732ae43", null ],
    [ "Version", "class_neosmartpen_1_1_net_1_1_metadata_1_1_model_1_1_book.html#a8be333faa23adc8e404666439c845f85", null ]
];
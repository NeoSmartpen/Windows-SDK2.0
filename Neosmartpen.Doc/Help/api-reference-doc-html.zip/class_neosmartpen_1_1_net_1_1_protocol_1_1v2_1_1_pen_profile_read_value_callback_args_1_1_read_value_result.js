var class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_profile_read_value_callback_args_1_1_read_value_result =
[
    [ "Data", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_profile_read_value_callback_args_1_1_read_value_result.html#a9039d9cf1d68f57f5bac4d6b207ccf23", null ],
    [ "Key", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_profile_read_value_callback_args_1_1_read_value_result.html#a7dc5ecd97fdea8581fdc2c48665313e6", null ],
    [ "Status", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_profile_read_value_callback_args_1_1_read_value_result.html#a7d64cd343ab4dba7f9f59b7d6ee14784", null ]
];
var _error_type_8cs =
[
    [ "ErrorType", "_error_type_8cs.html#a787509703bba2e741b73c625a93813a4", [
      [ "MissingPenUp", "_error_type_8cs.html#a787509703bba2e741b73c625a93813a4a022f89a9eefe308e53b5cab47d1fa10b", null ],
      [ "MissingPenDown", "_error_type_8cs.html#a787509703bba2e741b73c625a93813a4abbf1cee5e3e8a3d467301ef425a7def7", null ],
      [ "InvalidTime", "_error_type_8cs.html#a787509703bba2e741b73c625a93813a4a601b9f32a0f26e4a7529e0dcabde3146", null ],
      [ "MissingPenDownPenMove", "_error_type_8cs.html#a787509703bba2e741b73c625a93813a4a2437e062016f39f69132ac2570ff5193", null ],
      [ "ImageProcessingError", "_error_type_8cs.html#a787509703bba2e741b73c625a93813a4abdabc6b4b4c00ff3b151d3bde20d7b3f", null ],
      [ "InvalidEventCount", "_error_type_8cs.html#a787509703bba2e741b73c625a93813a4a6d41db8aaa7f9bc9b641d61a766b7eb8", null ],
      [ "MissingPageChange", "_error_type_8cs.html#a787509703bba2e741b73c625a93813a4a505a2c1b33e1753507bb0d158cc859ec", null ],
      [ "MissingPenMove", "_error_type_8cs.html#a787509703bba2e741b73c625a93813a4a0b753d2bad6305f248ed8f1bf8b7065a", null ]
    ] ]
];
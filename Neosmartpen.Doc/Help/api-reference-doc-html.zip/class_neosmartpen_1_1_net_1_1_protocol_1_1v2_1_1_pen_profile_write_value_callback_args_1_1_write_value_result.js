var class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_profile_write_value_callback_args_1_1_write_value_result =
[
    [ "Key", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_profile_write_value_callback_args_1_1_write_value_result.html#a7ffef437f7ad44efb58fe3351317deb7", null ],
    [ "Status", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_profile_write_value_callback_args_1_1_write_value_result.html#ab280128cc20999c52128c5c55eb3d796", null ]
];
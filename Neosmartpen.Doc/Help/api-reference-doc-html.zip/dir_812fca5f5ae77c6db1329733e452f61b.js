var dir_812fca5f5ae77c6db1329733e452f61b =
[
    [ "AssemblyInfo.cs", "_neosmartpen_8_net_8_protocol_8v2_2_properties_2_assembly_info_8cs.html", null ]
];
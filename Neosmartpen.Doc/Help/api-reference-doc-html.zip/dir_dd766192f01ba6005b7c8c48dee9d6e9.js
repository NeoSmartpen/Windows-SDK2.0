var dir_dd766192f01ba6005b7c8c48dee9d6e9 =
[
    [ "CallbackArgs", "dir_79dbc61148946d98a8ba380905ab73e9.html", "dir_79dbc61148946d98a8ba380905ab73e9" ],
    [ "ImageProcessErrorInfo.cs", "_image_process_error_info_8cs.html", [
      [ "ImageProcessErrorInfo", "class_neosmartpen_1_1_net_1_1_image_process_error_info.html", "class_neosmartpen_1_1_net_1_1_image_process_error_info" ]
    ] ],
    [ "ImageProcessingInfo.cs", "_image_processing_info_8cs.html", [
      [ "ImageProcessingInfo", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_image_processing_info.html", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_image_processing_info" ]
    ] ],
    [ "PenCommV2.cs", "_pen_comm_v2_8cs.html", [
      [ "PenCommV2", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_comm_v2.html", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_comm_v2" ]
    ] ],
    [ "PenCommV2Callbacks.cs", "_pen_comm_v2_callbacks_8cs.html", [
      [ "PenCommV2Callbacks", "interface_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_comm_v2_callbacks.html", "interface_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_comm_v2_callbacks" ]
    ] ],
    [ "PenProfile.cs", "_pen_profile_8cs.html", [
      [ "PenProfile", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_profile.html", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_profile" ]
    ] ],
    [ "Protocol.cs", "_protocol_8cs.html", "_protocol_8cs" ],
    [ "ProtocolParserV2.cs", "_protocol_parser_v2_8cs.html", [
      [ "ProtocolParserV2", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_protocol_parser_v2.html", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_protocol_parser_v2" ]
    ] ]
];
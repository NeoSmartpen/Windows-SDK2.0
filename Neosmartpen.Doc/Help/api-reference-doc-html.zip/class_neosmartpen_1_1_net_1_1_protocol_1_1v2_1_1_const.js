var class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_const =
[
    [ "PK_DLE", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_const.html#ac7aa7f2427eaf3fd24fa371e75564c41", null ],
    [ "PK_ETX", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_const.html#a3803ea7b15104838cc8e0eb399a43c26", null ],
    [ "PK_HEADER_SIZE", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_const.html#a7a56ab2050e64ebc5c20daebef822df9", null ],
    [ "PK_POS_CMD", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_const.html#a3d50b249bb59e231e7aa8ca75f89b014", null ],
    [ "PK_POS_LENG1", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_const.html#a585c1782ba147f7c9e17fc7b582a7241", null ],
    [ "PK_POS_LENG2", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_const.html#a4ae47bbe3a54dc65b424ef63faedf232", null ],
    [ "PK_POS_RESULT", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_const.html#af3b087c2ef977a1711ef3368e02cad41", null ],
    [ "PK_STX", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_const.html#a23826ca5a0bef4a2e9b1f191c5d9d15d", null ]
];
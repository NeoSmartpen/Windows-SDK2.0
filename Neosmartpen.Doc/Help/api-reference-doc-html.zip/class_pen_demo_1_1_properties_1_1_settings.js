var class_pen_demo_1_1_properties_1_1_settings =
[
    [ "Setting", "class_pen_demo_1_1_properties_1_1_settings.html#ae8d3d40ba585b469b5f2570444ba5b12", null ]
];
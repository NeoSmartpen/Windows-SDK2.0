var class_pen_demo_1_1_properties_1_1_settings =
[
    [ "Setting", "class_pen_demo_1_1_properties_1_1_settings.html#a757525ca75a3d64dfef47e9cc00c39da", null ]
];
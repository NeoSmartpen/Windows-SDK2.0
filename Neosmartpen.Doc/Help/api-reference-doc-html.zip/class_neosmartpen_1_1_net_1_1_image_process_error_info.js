var class_neosmartpen_1_1_net_1_1_image_process_error_info =
[
    [ "Brightness", "class_neosmartpen_1_1_net_1_1_image_process_error_info.html#ac59130c51befe08354c19e2739aa6481", null ],
    [ "ClassType", "class_neosmartpen_1_1_net_1_1_image_process_error_info.html#acf5a92475b08f60d20df617c2940f021", null ],
    [ "ErrorCode", "class_neosmartpen_1_1_net_1_1_image_process_error_info.html#aa99f22db86aff0c534e389e39260b01f", null ],
    [ "ErrorCount", "class_neosmartpen_1_1_net_1_1_image_process_error_info.html#acb19b6ab806c8cfc661b0f817bd07f09", null ],
    [ "ExposureTime", "class_neosmartpen_1_1_net_1_1_image_process_error_info.html#a4c3700c25272da808c88994224142202", null ],
    [ "Force", "class_neosmartpen_1_1_net_1_1_image_process_error_info.html#ad7808c3f7240777f6edb84b5e349c4e9", null ],
    [ "LabelCount", "class_neosmartpen_1_1_net_1_1_image_process_error_info.html#a136fb097b3843332e945399459019938", null ],
    [ "ProcessTime", "class_neosmartpen_1_1_net_1_1_image_process_error_info.html#ab79ffe0633ba9ba17ea2d65bb502a365", null ],
    [ "Timestamp", "class_neosmartpen_1_1_net_1_1_image_process_error_info.html#aecc10f7aa2e0ade895677a2b66e762b4", null ]
];
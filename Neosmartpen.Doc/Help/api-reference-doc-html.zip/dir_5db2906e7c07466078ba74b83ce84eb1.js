var dir_5db2906e7c07466078ba74b83ce84eb1 =
[
    [ "FilterForPaper.cs", "_filter_for_paper_8cs.html", [
      [ "FilterForPaper", "class_neosmartpen_1_1_net_1_1_filter_1_1_filter_for_paper.html", "class_neosmartpen_1_1_net_1_1_filter_1_1_filter_for_paper" ]
    ] ]
];
var class_neosmartpen_1_1_net_1_1_dot =
[
    [ "Builder", "class_neosmartpen_1_1_net_1_1_dot_1_1_builder.html", "class_neosmartpen_1_1_net_1_1_dot_1_1_builder" ],
    [ "Dot", "class_neosmartpen_1_1_net_1_1_dot.html#af049032e9380691e68ad7de54b9a6530", null ],
    [ "Dot", "class_neosmartpen_1_1_net_1_1_dot.html#a45ea403fdeb43960069348eeca9a94e6", null ],
    [ "Dot", "class_neosmartpen_1_1_net_1_1_dot.html#ac69d286ad9e3a7b26bf769ba3dc8b9ba", null ],
    [ "Clone", "class_neosmartpen_1_1_net_1_1_dot.html#a803093489847fe5d3910228964b403ef", null ],
    [ "ToString", "class_neosmartpen_1_1_net_1_1_dot.html#aff5a10a40ac7f634f1ad70a6611f8bfe", null ],
    [ "Color", "class_neosmartpen_1_1_net_1_1_dot.html#a040db60ccd8967305d143a2d3c4e1e2d", null ],
    [ "DotType", "class_neosmartpen_1_1_net_1_1_dot.html#a7224fb98c3b229bcd599cef829987897", null ],
    [ "Force", "class_neosmartpen_1_1_net_1_1_dot.html#a6b3a79898204dfd4b3b9a722f7a967ae", null ],
    [ "Fx", "class_neosmartpen_1_1_net_1_1_dot.html#ab2c2899bfd206f92b9824932b4039418", null ],
    [ "Fy", "class_neosmartpen_1_1_net_1_1_dot.html#a8044287ccd2750ea564da75533ccd201", null ],
    [ "Note", "class_neosmartpen_1_1_net_1_1_dot.html#a24c54817d705b3f1c86c0675e79a688f", null ],
    [ "Owner", "class_neosmartpen_1_1_net_1_1_dot.html#addc18694407a6befdd837e330bb36c4d", null ],
    [ "Page", "class_neosmartpen_1_1_net_1_1_dot.html#a9baa6f80653ddbc28694ab47e525fd75", null ],
    [ "Section", "class_neosmartpen_1_1_net_1_1_dot.html#a92b4fbc89a8b90b998335308dd909882", null ],
    [ "TiltX", "class_neosmartpen_1_1_net_1_1_dot.html#a5e240e8d795e3ab42841c879f937e1e5", null ],
    [ "TiltY", "class_neosmartpen_1_1_net_1_1_dot.html#a2754f0599041fae4e4de264544728235", null ],
    [ "Timestamp", "class_neosmartpen_1_1_net_1_1_dot.html#a4eda5194883886f95ce5719531fb12ea", null ],
    [ "Twist", "class_neosmartpen_1_1_net_1_1_dot.html#a8fa2ce1a51aa4860cd5bb63ca5fa9253", null ],
    [ "X", "class_neosmartpen_1_1_net_1_1_dot.html#a015d600b36f87e9e77d14d7da454bcfd", null ],
    [ "Y", "class_neosmartpen_1_1_net_1_1_dot.html#ab8266ebed791329ebdcf319c7d1ac04d", null ]
];
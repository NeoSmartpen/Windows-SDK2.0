var class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_profile_received_callback_args =
[
    [ "PenProfileType", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_profile_received_callback_args.html#a4cd008e024437f4b85e78e63e17b6d45", [
      [ "Create", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_profile_received_callback_args.html#a4cd008e024437f4b85e78e63e17b6d45a686e697538050e4664636337cc3b834f", null ],
      [ "Delete", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_profile_received_callback_args.html#a4cd008e024437f4b85e78e63e17b6d45af2a6c498fb90ee345d997f888fce3b18", null ],
      [ "Info", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_profile_received_callback_args.html#a4cd008e024437f4b85e78e63e17b6d45a4059b0251f66a18cb56f544728796875", null ],
      [ "ReadValue", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_profile_received_callback_args.html#a4cd008e024437f4b85e78e63e17b6d45a9e41411920c1f8698322c4e01a7756f8", null ],
      [ "WriteValue", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_profile_received_callback_args.html#a4cd008e024437f4b85e78e63e17b6d45a290f2db6998056c4873796bcbb0ba885", null ],
      [ "DeleteValue", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_profile_received_callback_args.html#a4cd008e024437f4b85e78e63e17b6d45a7906fd1ab2c3f328f65dda484c5fb042", null ]
    ] ],
    [ "ResultType", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_profile_received_callback_args.html#a5eb18c1c9374cfe16c618d767eaa6c55", [
      [ "Success", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_profile_received_callback_args.html#a5eb18c1c9374cfe16c618d767eaa6c55a505a83f220c02df2f85c3810cd9ceb38", null ],
      [ "Failed", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_profile_received_callback_args.html#a5eb18c1c9374cfe16c618d767eaa6c55ad7c8c85bf79bbe1b7188497c32c3b0ca", null ]
    ] ],
    [ "ProfileName", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_profile_received_callback_args.html#a06010fcde3832f52173eb7312e02c36f", null ],
    [ "Result", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_profile_received_callback_args.html#a7fd9628205d2e8d0ec2924333c2b20bc", null ],
    [ "Status", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_profile_received_callback_args.html#a3b8de06e2f7f167ea319b55cceda818a", null ],
    [ "Type", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_profile_received_callback_args.html#ae837e2e7d0abd672b6bd8fa374c465ee", null ]
];
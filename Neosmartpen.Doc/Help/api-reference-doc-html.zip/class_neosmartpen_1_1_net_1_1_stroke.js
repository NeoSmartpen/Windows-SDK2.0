var class_neosmartpen_1_1_net_1_1_stroke =
[
    [ "Stroke", "class_neosmartpen_1_1_net_1_1_stroke.html#ae5144dd98e73c1ea091c103ae8a89476", null ],
    [ "Add", "class_neosmartpen_1_1_net_1_1_stroke.html#a567080183c282fc09d0613858645ee82", null ],
    [ "GetRect", "class_neosmartpen_1_1_net_1_1_stroke.html#ab833fa8c3fbbac2dfd51bc8274e0e41b", null ],
    [ "ToString", "class_neosmartpen_1_1_net_1_1_stroke.html#a677d9e30252177ea9ea205a32ae67a17", null ],
    [ "Color", "class_neosmartpen_1_1_net_1_1_stroke.html#a64e2cd291bb0a774dfa9c619f3c861e6", null ],
    [ "Note", "class_neosmartpen_1_1_net_1_1_stroke.html#ac17163576bf79146ad4d03d1c454d3ed", null ],
    [ "Owner", "class_neosmartpen_1_1_net_1_1_stroke.html#afc28d5614887d33afac1a6dcaea737df", null ],
    [ "Page", "class_neosmartpen_1_1_net_1_1_stroke.html#aac0e1df533fbd9e27e081f5a6490a624", null ],
    [ "Section", "class_neosmartpen_1_1_net_1_1_stroke.html#a34c8bca487d255221b7fc8e4d10ca3bb", null ],
    [ "TimeEnd", "class_neosmartpen_1_1_net_1_1_stroke.html#a2f700c23edeb9546e5c6c3a579370751", null ],
    [ "TimeStart", "class_neosmartpen_1_1_net_1_1_stroke.html#a5be7acfe506f66ba9141c1e1ab69d995", null ]
];
var class_neosmartpen_1_1_net_1_1_packet_event_args =
[
    [ "PacketEventArgs", "class_neosmartpen_1_1_net_1_1_packet_event_args.html#a9a8869794b2af93650352581ab3aa28b", null ],
    [ "Packet", "class_neosmartpen_1_1_net_1_1_packet_event_args.html#a1ccba189ade725e91babbf2e23ed46d9", null ]
];
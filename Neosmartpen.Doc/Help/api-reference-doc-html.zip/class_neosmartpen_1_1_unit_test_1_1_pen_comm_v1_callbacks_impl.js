var class_neosmartpen_1_1_unit_test_1_1_pen_comm_v1_callbacks_impl =
[
    [ "CallbackDele", "class_neosmartpen_1_1_unit_test_1_1_pen_comm_v1_callbacks_impl.html#ae858decae05e9fce427a90b4d307093d", null ],
    [ "Dispose", "class_neosmartpen_1_1_unit_test_1_1_pen_comm_v1_callbacks_impl.html#a3bbc405f60bf2daba1dc2b72e8e20b1e", null ],
    [ "Authenticated", "class_neosmartpen_1_1_unit_test_1_1_pen_comm_v1_callbacks_impl.html#a2556033cb553378486ef626a3a154a8f", null ],
    [ "AutoPowerOnChanged", "class_neosmartpen_1_1_unit_test_1_1_pen_comm_v1_callbacks_impl.html#af7cc47278c1f70ff583a1952da64ca33", null ],
    [ "AutoShutdownTimeChanged", "class_neosmartpen_1_1_unit_test_1_1_pen_comm_v1_callbacks_impl.html#af3d2bf1f866d88533da5c45f40cbf51b", null ],
    [ "AvailableNoteAccepted", "class_neosmartpen_1_1_unit_test_1_1_pen_comm_v1_callbacks_impl.html#a6a6d66db8cdfc45c5c06992eb6fea4d8", null ],
    [ "Connected", "class_neosmartpen_1_1_unit_test_1_1_pen_comm_v1_callbacks_impl.html#a1eb09c4ae7fdac1d7f6ccebcbd415a11", null ],
    [ "Disconnected", "class_neosmartpen_1_1_unit_test_1_1_pen_comm_v1_callbacks_impl.html#a047c27fb8ec4e79e8bca592e39344973", null ],
    [ "FirmwareUpdateProgressReceived", "class_neosmartpen_1_1_unit_test_1_1_pen_comm_v1_callbacks_impl.html#a8bf6e2462eb5842a9a9c893cd0a5223d", null ],
    [ "FirmwareUpdateResultReceived", "class_neosmartpen_1_1_unit_test_1_1_pen_comm_v1_callbacks_impl.html#a2f2824fa3f2119c10c90a032bf4a569a", null ],
    [ "OfflineDataDownloadingFinished", "class_neosmartpen_1_1_unit_test_1_1_pen_comm_v1_callbacks_impl.html#aa9e90f54693ec33fa3d9612694baa835", null ],
    [ "OfflineDataDownloadingStarted", "class_neosmartpen_1_1_unit_test_1_1_pen_comm_v1_callbacks_impl.html#a0bac7da286075576d3f243dd9b7662da", null ],
    [ "OfflineDataListReceived", "class_neosmartpen_1_1_unit_test_1_1_pen_comm_v1_callbacks_impl.html#a9e2b46e638680d02fcaef5377269b8e9", null ],
    [ "OfflineStrokesReceived", "class_neosmartpen_1_1_unit_test_1_1_pen_comm_v1_callbacks_impl.html#aaf09e1b26a1fcf6a6c51f3193834f105", null ],
    [ "PasswordChanged", "class_neosmartpen_1_1_unit_test_1_1_pen_comm_v1_callbacks_impl.html#a71623f17cf4ba7cdf8f86f03f369c49f", null ],
    [ "PasswordRequest", "class_neosmartpen_1_1_unit_test_1_1_pen_comm_v1_callbacks_impl.html#ac5ef39f7bc2a164c2f7bcad42942a58f", null ],
    [ "PenBeepChanged", "class_neosmartpen_1_1_unit_test_1_1_pen_comm_v1_callbacks_impl.html#a0ccef7e1e731a2e7dcac86fddd5a1b1c", null ],
    [ "PenColorChanged", "class_neosmartpen_1_1_unit_test_1_1_pen_comm_v1_callbacks_impl.html#aa8688f93a61a940149d41909079e5c12", null ],
    [ "PenHoverChanged", "class_neosmartpen_1_1_unit_test_1_1_pen_comm_v1_callbacks_impl.html#a1058e83868a1c7a6c67180ec7f4a10f3", null ],
    [ "PenSensitivityChanged", "class_neosmartpen_1_1_unit_test_1_1_pen_comm_v1_callbacks_impl.html#a93ed9a1d253f3c6b69cb14b02a876206", null ],
    [ "PenStatusReceived", "class_neosmartpen_1_1_unit_test_1_1_pen_comm_v1_callbacks_impl.html#a9908119943de0badcd64c10f8b9ba337", null ]
];
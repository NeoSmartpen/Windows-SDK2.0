var class_neosmartpen_1_1_net_1_1_filter_1_1_filter_for_paper =
[
    [ "FilterForPaper", "class_neosmartpen_1_1_net_1_1_filter_1_1_filter_for_paper.html#a241f287a2859259071748ce44dd7db46", null ],
    [ "FilteredDot", "class_neosmartpen_1_1_net_1_1_filter_1_1_filter_for_paper.html#a56f811e99f05c8037a81f47b33eb42d7", null ],
    [ "Put", "class_neosmartpen_1_1_net_1_1_filter_1_1_filter_for_paper.html#a63daedf075589c9f9e6cf34d19b612fc", null ]
];
var class_neosmartpen_1_1_net_1_1_pen_comm =
[
    [ "PenComm", "class_neosmartpen_1_1_net_1_1_pen_comm.html#a268dc942c4d31f954b2e4706eac8ff46", null ],
    [ "Bind", "class_neosmartpen_1_1_net_1_1_pen_comm.html#a9f3787b3fd98c0918a5d73f4063958a8", null ],
    [ "Clean", "class_neosmartpen_1_1_net_1_1_pen_comm.html#afd7730151d20c7bd3ccdc829f3fffb1e", null ],
    [ "GetPressureCalibrationFactor", "class_neosmartpen_1_1_net_1_1_pen_comm.html#a4b26d0b4e97102bf968e3fbd9c032c50", null ],
    [ "OnConnected", "class_neosmartpen_1_1_net_1_1_pen_comm.html#aeaf59f4c94bd18450b215d31a5fc386c", null ],
    [ "OnDisconnected", "class_neosmartpen_1_1_net_1_1_pen_comm.html#acfa1b684ff5d3205c27cd4c156531cb5", null ],
    [ "SetPressureCalibrateFactor", "class_neosmartpen_1_1_net_1_1_pen_comm.html#ae9dde4e15f19852ebbc853149078a794", null ],
    [ "Write", "class_neosmartpen_1_1_net_1_1_pen_comm.html#abd39e2cd345bed5cfde3a4195ef56f9e", null ],
    [ "Alive", "class_neosmartpen_1_1_net_1_1_pen_comm.html#a9ddb4577b822940e7a90b73f67dc0e2c", null ],
    [ "DeviceClass", "class_neosmartpen_1_1_net_1_1_pen_comm.html#a66d68c1c276ece209f730ce936c1d8db", null ],
    [ "MetadataManager", "class_neosmartpen_1_1_net_1_1_pen_comm.html#a5a7b25aeefcccbf424e52634b33fabb0", null ],
    [ "mSock", "class_neosmartpen_1_1_net_1_1_pen_comm.html#a5213cee51ab760454ec7b4c840cd0913", null ],
    [ "mStream", "class_neosmartpen_1_1_net_1_1_pen_comm.html#ab1b8974f6c29bed3b71c1552ad5ae3da", null ],
    [ "Name", "class_neosmartpen_1_1_net_1_1_pen_comm.html#a5dd50875686f5552f42357f3802bb84e", null ],
    [ "Parser", "class_neosmartpen_1_1_net_1_1_pen_comm.html#a891be07c415281db3f7fa3b6c8cedf74", null ],
    [ "Version", "class_neosmartpen_1_1_net_1_1_pen_comm.html#ad75d6c653c0c82bae1c35194e13f922f", null ]
];
var dir_60dda0bacc892cb38caf3b2b5042ae2e =
[
    [ "Bluetooth", "dir_efacc478aa8a126f62bce05e7c8f6b90.html", "dir_efacc478aa8a126f62bce05e7c8f6b90" ],
    [ "Filter", "dir_5db2906e7c07466078ba74b83ce84eb1.html", "dir_5db2906e7c07466078ba74b83ce84eb1" ],
    [ "Metadata", "dir_131714f9a13f0e4e0f301c6f7adb83dd.html", "dir_131714f9a13f0e4e0f301c6f7adb83dd" ],
    [ "Support", "dir_4c8df66eea6bee42930742cadc26232e.html", "dir_4c8df66eea6bee42930742cadc26232e" ],
    [ "Chunk.cs", "_chunk_8cs.html", [
      [ "Chunk", "class_neosmartpen_1_1_net_1_1_chunk.html", "class_neosmartpen_1_1_net_1_1_chunk" ]
    ] ],
    [ "Dot.cs", "_dot_8cs.html", "_dot_8cs" ],
    [ "ErrorType.cs", "_error_type_8cs.html", "_error_type_8cs" ],
    [ "IPacket.cs", "_i_packet_8cs.html", [
      [ "IPacket", "interface_neosmartpen_1_1_net_1_1_i_packet.html", "interface_neosmartpen_1_1_net_1_1_i_packet" ]
    ] ],
    [ "IPenComm.cs", "_i_pen_comm_8cs.html", [
      [ "IPenComm", "interface_neosmartpen_1_1_net_1_1_i_pen_comm.html", "interface_neosmartpen_1_1_net_1_1_i_pen_comm" ]
    ] ],
    [ "IProtocolParser.cs", "_i_protocol_parser_8cs.html", [
      [ "IProtocolParser", "interface_neosmartpen_1_1_net_1_1_i_protocol_parser.html", "interface_neosmartpen_1_1_net_1_1_i_protocol_parser" ],
      [ "PacketEventArgs", "class_neosmartpen_1_1_net_1_1_packet_event_args.html", "class_neosmartpen_1_1_net_1_1_packet_event_args" ]
    ] ],
    [ "OfflineDataStructure.cs", "_offline_data_structure_8cs.html", [
      [ "OfflineDataInfo", "class_neosmartpen_1_1_net_1_1_offline_data_info.html", "class_neosmartpen_1_1_net_1_1_offline_data_info" ],
      [ "OfflineDataFile", "class_neosmartpen_1_1_net_1_1_offline_data_file.html", "class_neosmartpen_1_1_net_1_1_offline_data_file" ]
    ] ],
    [ "Packet.cs", "_packet_8cs.html", [
      [ "Packet", "class_neosmartpen_1_1_net_1_1_packet.html", "class_neosmartpen_1_1_net_1_1_packet" ],
      [ "Builder", "class_neosmartpen_1_1_net_1_1_packet_1_1_builder.html", "class_neosmartpen_1_1_net_1_1_packet_1_1_builder" ]
    ] ],
    [ "PenComm.cs", "_pen_comm_8cs.html", [
      [ "PenComm", "class_neosmartpen_1_1_net_1_1_pen_comm.html", "class_neosmartpen_1_1_net_1_1_pen_comm" ]
    ] ],
    [ "Stroke.cs", "_stroke_8cs.html", [
      [ "Stroke", "class_neosmartpen_1_1_net_1_1_stroke.html", "class_neosmartpen_1_1_net_1_1_stroke" ]
    ] ]
];
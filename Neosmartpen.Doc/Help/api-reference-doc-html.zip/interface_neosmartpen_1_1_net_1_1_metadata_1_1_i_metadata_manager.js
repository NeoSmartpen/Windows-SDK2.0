var interface_neosmartpen_1_1_net_1_1_metadata_1_1_i_metadata_manager =
[
    [ "FindApplicableSymbols", "interface_neosmartpen_1_1_net_1_1_metadata_1_1_i_metadata_manager.html#af4af7d053dbe454e4b0e35980851a465", null ],
    [ "GetBook", "interface_neosmartpen_1_1_net_1_1_metadata_1_1_i_metadata_manager.html#ace29e195022e2dbffcc8d95eb6f944e2", null ],
    [ "GetPage", "interface_neosmartpen_1_1_net_1_1_metadata_1_1_i_metadata_manager.html#ad688726dfb03d1f1d95d20135bc1e647", null ],
    [ "GetStrokesInSymbol", "interface_neosmartpen_1_1_net_1_1_metadata_1_1_i_metadata_manager.html#ae4a9d86d9b574d6817f77b87ea3c9731", null ],
    [ "GetSymbols", "interface_neosmartpen_1_1_net_1_1_metadata_1_1_i_metadata_manager.html#ab672677210714c2e2d77be19084e76f9", null ],
    [ "Load", "interface_neosmartpen_1_1_net_1_1_metadata_1_1_i_metadata_manager.html#aa5aec4454c7852260da76c79d4aa47b8", null ],
    [ "Parser", "interface_neosmartpen_1_1_net_1_1_metadata_1_1_i_metadata_manager.html#a1ad2b382a649803a37b56395e6505b1e", null ]
];
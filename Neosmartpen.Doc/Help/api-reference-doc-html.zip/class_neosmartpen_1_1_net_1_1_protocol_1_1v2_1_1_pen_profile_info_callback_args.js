var class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_profile_info_callback_args =
[
    [ "SectionSize", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_profile_info_callback_args.html#a2e4a2a2489a515dea55d2023fb79f885", null ],
    [ "TotalSectionCount", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_profile_info_callback_args.html#a7f73497197f9ed6753239ecc3ad2fd06", null ],
    [ "UseKeyCount", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_profile_info_callback_args.html#afcd61a3de903d49feb8d888b24caa091", null ],
    [ "UseSectionCount", "class_neosmartpen_1_1_net_1_1_protocol_1_1v2_1_1_pen_profile_info_callback_args.html#aaaf11db2893cc2e01e067caae6152fa9", null ]
];
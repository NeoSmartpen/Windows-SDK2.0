var namespace_neosmartpen_1_1_net_1_1_protocol =
[
    [ "v1", "namespace_neosmartpen_1_1_net_1_1_protocol_1_1v1.html", "namespace_neosmartpen_1_1_net_1_1_protocol_1_1v1" ],
    [ "v2", "namespace_neosmartpen_1_1_net_1_1_protocol_1_1v2.html", "namespace_neosmartpen_1_1_net_1_1_protocol_1_1v2" ]
];
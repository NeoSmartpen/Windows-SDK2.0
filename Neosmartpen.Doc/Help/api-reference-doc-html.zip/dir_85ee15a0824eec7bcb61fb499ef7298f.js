var dir_85ee15a0824eec7bcb61fb499ef7298f =
[
    [ "AssemblyInfo.cs", "_0D_s_d_k_01release_2_neosmartpen_s_d_k2_80__beta__160728__to___n_l_taiwan_2_neosmartpen_8_demo_ca1e8b6f976a74ac17c6a6402ebfd7bc.html", null ],
    [ "Resources.Designer.cs", "_0D_s_d_k_01release_2_neosmartpen_s_d_k2_80__beta__160728__to___n_l_taiwan_2_neosmartpen_8_demo_e4025671a3bf6dde117a3ab23682f4d1.html", [
      [ "Resources", "class_pen_demo_1_1_properties_1_1_resources.html", null ]
    ] ],
    [ "Settings.Designer.cs", "_0D_s_d_k_01release_2_neosmartpen_s_d_k2_80__beta__160728__to___n_l_taiwan_2_neosmartpen_8_demo_f61c7656bb5f022be5ea19ad36a6acce.html", [
      [ "Settings", "class_pen_demo_1_1_properties_1_1_settings.html", "class_pen_demo_1_1_properties_1_1_settings" ]
    ] ]
];
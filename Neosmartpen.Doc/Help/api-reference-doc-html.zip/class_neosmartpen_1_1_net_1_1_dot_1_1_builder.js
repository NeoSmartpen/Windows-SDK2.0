var class_neosmartpen_1_1_net_1_1_dot_1_1_builder =
[
    [ "Builder", "class_neosmartpen_1_1_net_1_1_dot_1_1_builder.html#abdbac806cba995430d23bf7a14c54f16", null ],
    [ "Builder", "class_neosmartpen_1_1_net_1_1_dot_1_1_builder.html#ab07ade25cc1bb7be6ffe3c0a2ed4c547", null ],
    [ "Build", "class_neosmartpen_1_1_net_1_1_dot_1_1_builder.html#a1f1bd035373bf40f0fb540ce95e8e2c4", null ],
    [ "color", "class_neosmartpen_1_1_net_1_1_dot_1_1_builder.html#a7b230a152ccbce7ab562e84e817a28a3", null ],
    [ "coord", "class_neosmartpen_1_1_net_1_1_dot_1_1_builder.html#a486f861643cd6d2c78eea8e0529ff1f8", null ],
    [ "dotType", "class_neosmartpen_1_1_net_1_1_dot_1_1_builder.html#ac69d0a89724ce66d58755ff198f93d04", null ],
    [ "force", "class_neosmartpen_1_1_net_1_1_dot_1_1_builder.html#ab81c898f05630ef6170dfd0d02314a92", null ],
    [ "note", "class_neosmartpen_1_1_net_1_1_dot_1_1_builder.html#a9c6b1fdd7d50688b844254445aba622d", null ],
    [ "owner", "class_neosmartpen_1_1_net_1_1_dot_1_1_builder.html#ac10379465558b9cb340317454455774b", null ],
    [ "page", "class_neosmartpen_1_1_net_1_1_dot_1_1_builder.html#ab9fe064d816832ff99b99d8b226ce835", null ],
    [ "section", "class_neosmartpen_1_1_net_1_1_dot_1_1_builder.html#acd54863e046160be75f34855891f8c68", null ],
    [ "tilt", "class_neosmartpen_1_1_net_1_1_dot_1_1_builder.html#a10a9aa413a8a931db501662f7a6d52d3", null ],
    [ "timestamp", "class_neosmartpen_1_1_net_1_1_dot_1_1_builder.html#add55bd95d3c471799f225e2a10c3ecb2", null ],
    [ "twist", "class_neosmartpen_1_1_net_1_1_dot_1_1_builder.html#a37ecaac00540e27242d8f2b78cfde017", null ]
];
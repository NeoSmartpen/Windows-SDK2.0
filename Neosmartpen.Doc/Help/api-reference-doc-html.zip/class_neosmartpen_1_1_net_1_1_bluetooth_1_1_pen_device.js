var class_neosmartpen_1_1_net_1_1_bluetooth_1_1_pen_device =
[
    [ "ToString", "class_neosmartpen_1_1_net_1_1_bluetooth_1_1_pen_device.html#a0c2627fa95ffad969234b21fb01ec6cc", null ],
    [ "Address", "class_neosmartpen_1_1_net_1_1_bluetooth_1_1_pen_device.html#ac04c0d53e5d4f49bf80e4aef5dec2297", null ],
    [ "Authenticated", "class_neosmartpen_1_1_net_1_1_bluetooth_1_1_pen_device.html#a6e549122eeeaf2430ddee53683bffebc", null ],
    [ "ClassOfDevice", "class_neosmartpen_1_1_net_1_1_bluetooth_1_1_pen_device.html#a1e637f9420c48bc6f61d03a3473ddbf8", null ],
    [ "LastSeen", "class_neosmartpen_1_1_net_1_1_bluetooth_1_1_pen_device.html#a5ad5959e078bb8bb2f7a615122690e72", null ],
    [ "LastUsed", "class_neosmartpen_1_1_net_1_1_bluetooth_1_1_pen_device.html#ab1e355a6ea96b46b9dfba4da897cd439", null ],
    [ "Name", "class_neosmartpen_1_1_net_1_1_bluetooth_1_1_pen_device.html#ac3e2b262dd621960b96eed65609cbe78", null ],
    [ "Remembered", "class_neosmartpen_1_1_net_1_1_bluetooth_1_1_pen_device.html#ab29dd9376d4c65641fac61dcd53faf6b", null ],
    [ "Rssi", "class_neosmartpen_1_1_net_1_1_bluetooth_1_1_pen_device.html#a863f137b26f6973539c5e5e34413b2a2", null ]
];
var dir_56c7bea15569225bf4219724cf1d53b4 =
[
    [ "AssemblyInfo.cs", "_0D_s_d_k_01release_2_neosmartpen_s_d_k2_80__beta__160817__to_01_front_sight_2_neosmartpen_8_demcb0fbd07742ecf4a283be78cc6207144.html", null ],
    [ "Resources.Designer.cs", "_0D_s_d_k_01release_2_neosmartpen_s_d_k2_80__beta__160817__to_01_front_sight_2_neosmartpen_8_demb8a83f182b298d6a018e81a844c503a1.html", [
      [ "Resources", "class_pen_demo_1_1_properties_1_1_resources.html", null ]
    ] ],
    [ "Settings.Designer.cs", "_0D_s_d_k_01release_2_neosmartpen_s_d_k2_80__beta__160817__to_01_front_sight_2_neosmartpen_8_dem05fc80e13f035257b79db70c0e2ea393.html", [
      [ "Settings", "class_pen_demo_1_1_properties_1_1_settings.html", "class_pen_demo_1_1_properties_1_1_settings" ]
    ] ]
];
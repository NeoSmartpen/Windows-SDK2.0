var dir_43138d24c289c05903a7b72597b2f173 =
[
    [ "Bluetooth", "dir_b87d8c1e906478a7a8bbb0ce29c5cec7.html", "dir_b87d8c1e906478a7a8bbb0ce29c5cec7" ],
    [ "Filter", "dir_73e8903acadc047a5ace1613cc586c16.html", "dir_73e8903acadc047a5ace1613cc586c16" ],
    [ "Metadata", "dir_a97ba3293ba17ad64a94665a34f43bb5.html", "dir_a97ba3293ba17ad64a94665a34f43bb5" ],
    [ "Support", "dir_fa047b20bdc6e274908af59f9e278d09.html", "dir_fa047b20bdc6e274908af59f9e278d09" ],
    [ "Chunk.cs", "_chunk_8cs.html", [
      [ "Chunk", "class_neosmartpen_1_1_net_1_1_chunk.html", "class_neosmartpen_1_1_net_1_1_chunk" ]
    ] ],
    [ "Dot.cs", "_dot_8cs.html", "_dot_8cs" ],
    [ "ErrorType.cs", "_error_type_8cs.html", "_error_type_8cs" ],
    [ "IPacket.cs", "_i_packet_8cs.html", [
      [ "IPacket", "interface_neosmartpen_1_1_net_1_1_i_packet.html", "interface_neosmartpen_1_1_net_1_1_i_packet" ]
    ] ],
    [ "IPenComm.cs", "_i_pen_comm_8cs.html", [
      [ "IPenComm", "interface_neosmartpen_1_1_net_1_1_i_pen_comm.html", "interface_neosmartpen_1_1_net_1_1_i_pen_comm" ]
    ] ],
    [ "IProtocolParser.cs", "_i_protocol_parser_8cs.html", [
      [ "IProtocolParser", "interface_neosmartpen_1_1_net_1_1_i_protocol_parser.html", "interface_neosmartpen_1_1_net_1_1_i_protocol_parser" ],
      [ "PacketEventArgs", "class_neosmartpen_1_1_net_1_1_packet_event_args.html", "class_neosmartpen_1_1_net_1_1_packet_event_args" ]
    ] ],
    [ "OfflineDataStructure.cs", "_offline_data_structure_8cs.html", [
      [ "OfflineDataInfo", "class_neosmartpen_1_1_net_1_1_offline_data_info.html", "class_neosmartpen_1_1_net_1_1_offline_data_info" ],
      [ "OfflineDataFile", "class_neosmartpen_1_1_net_1_1_offline_data_file.html", "class_neosmartpen_1_1_net_1_1_offline_data_file" ]
    ] ],
    [ "Packet.cs", "_packet_8cs.html", [
      [ "Packet", "class_neosmartpen_1_1_net_1_1_packet.html", "class_neosmartpen_1_1_net_1_1_packet" ],
      [ "Builder", "class_neosmartpen_1_1_net_1_1_packet_1_1_builder.html", "class_neosmartpen_1_1_net_1_1_packet_1_1_builder" ]
    ] ],
    [ "PenComm.cs", "_pen_comm_8cs.html", [
      [ "PenComm", "class_neosmartpen_1_1_net_1_1_pen_comm.html", "class_neosmartpen_1_1_net_1_1_pen_comm" ]
    ] ],
    [ "Stroke.cs", "_stroke_8cs.html", [
      [ "Stroke", "class_neosmartpen_1_1_net_1_1_stroke.html", "class_neosmartpen_1_1_net_1_1_stroke" ]
    ] ]
];